

<?php $__env->startSection('content'); ?>
    <div class="nk-block nk-block-lg">
        <div class="nk-block-head">
            <div class="nk-block-head-content">
                <h4 class="nk-block-title"><?php echo e($data['title']); ?></h4>
               
            </div>
        </div>
        <div class="card card-bordered card-preview">
            <div class="card-inner full-width">
                
                <div class="table-responsive">
                    <table width="100%" class="table wrap table-bordered table-striped" id="TblValidasi">
                        <thead class="table-light text-center">
                            <tr>

                                <th width="5%">No</th>
                                <th width="18%">Wajib Pajak</th>
                                <th width="20%">Alamat Objek Pajak</th>
                                <th>Kecamatan</th>
                                <th>Kelurahan</th>
                                <th>Bukti Dukung</th>
                                <th>Stakeholder</th>
                                <th width="10%">Aksi</th>
                            </tr>
                        </thead>

                    </table>
                </div>

            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\piwaraan\resources\views/validasi/index.blade.php ENDPATH**/ ?>